package com.cg.movies.exceptions;

public class SongNotFoundException extends Exception {

	public SongNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SongNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public SongNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public SongNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SongNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
